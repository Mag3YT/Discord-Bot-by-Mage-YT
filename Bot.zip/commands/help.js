const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    let sicon = message.guild.iconURL;
    let serverembed = new Discord.RichEmbed()
.addField("Zgar Service",["Here are all the Commands"],true)
    .setColor("#00990f")
    .setThumbnail(sicon)
  .addBlankField(true)

    

.addField("!helpfun",["For Help On Fun/ Game Commands"],true)
  .addBlankField(true)

  
.addField("!helpnsfw",["Help On NSFW Commands"],true)
  .addBlankField(true)
    
  .addField("!helpmod",["Help On Modderation Commands"],true)
  .addBlankField(true)

.addField("More commands comming soon.",["Bot Made By Mage YT#5912"],true)
.addField("Join My Server.",["https://discord.gg/4dzmScv"],true)

    message.channel.send(serverembed);
}

module.exports.help = {
  name:"help"
}