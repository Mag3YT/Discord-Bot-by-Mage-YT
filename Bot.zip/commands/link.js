const Discord = module.require('discord.js');

module.exports.run = async (bot, message, args, prefix) => {

    message.channel.send("https://discordapp.com/oauth2/authorize?client_id=549382463391137813&permissions=8&scope=bot&permissions=8");

}

module.exports.help = {
    name: "link"
}