const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    let bUser = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
    if(!bUser) return message.channel.send("Couldn't find user.");
    let rreason = args.join(" ").slice(22);

    let reportEmbed = new Discord.RichEmbed()
    .setDescription("Ban")
    .setColor("#840000")
    .addField("Banned User", `${bUser} with ID: ${bUser.id}`)
    .addField("Banned By", `${message.author} with ID: ${message.author.id}`)
    .addField("Channel", message.channel)
    .addField("Time", message.createdAt)
    .addField("Reason", rreason);

    let incidentchannel = message.guild.channels.find(`name`, "incidents");
    if(!incidentchannel) return message.channel.send("Couldn't find reports channel.");


    message.delete().catch(O_o=>{});
    incidentchannel.send(reportEmbed);

}
 
module.exports.help = {
  name: "ban"
}