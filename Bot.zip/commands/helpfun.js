const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    let sicon = message.guild.iconURL;
    let serverembed = new Discord.RichEmbed()
.addField("Zgar Service",["Here are all the Commands"],true)
    .setColor("#00990f")
    .setThumbnail(sicon)
      .addBlankField(true)

.addField("!love",["love meter."],true)  
    
.addField("!gay",["determines how gay u are"],true)  .addBlankField(true)

.addField("!hug",["hugs a user."],true)  

.addField("!fmk",["F*ck Marry or Kill a User."],true)  .addBlankField(true)

.addField("kiss",["kisses a user."],true)  

.addField("!cuddle",["cuddles a user."],true)  .addBlankField(true)

.addField("!slap",["slaps a user."],true) 

.addField("!punch",["punches a user"],true)  .addBlankField(true)

.addField("!ascii",["makes the text ascii"],true)  
.addField("!say",["bot repeats"],true)  .addBlankField(true)

.addField("!prefix",["changes the bot prefix"],true)  

.addField("!addrole",["gives the user the role"],true)  .addBlankField(true)

.addField("!8ball",["Ask it anything"],true)      
   

.addField("!meme",["Gets a funny meme"],true)

    .addField("!rps",["Rock Paper Scissors"],true)
    .addField("!quiz",["it ask a random quiz"],true)

    .addField("More commands comming soon.",["Bot Made By Mage YT#5912"],true)

    
    message.channel.send(serverembed);
}

module.exports.help = {
  name:"helpfun"
}