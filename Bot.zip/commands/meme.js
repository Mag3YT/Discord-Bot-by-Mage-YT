const Discord = require("discord.js");
const superagent = require("superagent");

exports.run = async (bot, message, args) => {



    const {body} = await superagent
    .get(`https://api-to.get-a.life/meme`);

    let hugEmbed = new Discord.RichEmbed()
    .setTitle("Memes! c:")
    .setDescription(`**${message.author.username}**`)
    .setImage(body.url)
    .setColor("RANDOM")
    .setFooter("Bot Version: 0.0.1", bot.user.displayAvatarURL);

    message.channel.send(hugEmbed)

}

module.exports.help = {
    name: "meme"
}