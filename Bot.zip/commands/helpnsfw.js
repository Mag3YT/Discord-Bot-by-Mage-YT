const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    let sicon = message.guild.iconURL;
    let serverembed = new Discord.RichEmbed()
.addField("Zgar Service",["Here are all the Commands"],true)
    .setColor("#00990f")
    .setThumbnail(sicon)
  .addBlankField(true)
      .addBlankField(true)

.addField("!hentai",["Its Hentai Gif."],true)
  .addBlankField(true)
  .addBlankField(true)

.addField("!pussy",["Its Pussy Gif."],true)
  .addBlankField(true)
  .addBlankField(true)

.addField("!boobs",["Its Boob Gif."],true)


      .addBlankField(true)
  .addBlankField(true)
    
.addField("!lewd",["For Random Graphic Hentai Gif."],true)
    
.addField("!gif",["For Random Porn Gif."],true)

.addField("More commands comming soon.",["Bot Made By Mage YT#5912"],true)

    message.channel.send(serverembed);
}

module.exports.help = {
  name:"helpnsfw"
}