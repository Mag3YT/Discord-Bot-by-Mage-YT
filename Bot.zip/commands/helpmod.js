const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    let sicon = message.guild.iconURL;
    let serverembed = new Discord.RichEmbed()
.addField("Zgar Service",["Here are all the Commands"],true)
    .setColor("#00990f")
    .setThumbnail(sicon)
      .addBlankField(true)
  .addBlankField(true)

.addField("!eval",["Evaluates"],true)

.addField("!kick",["kicks the user  you mention"],true)
        .addBlankField(true)


.addField("!ban",[" bans the user you mention"],true)

.addField("!report",["sends a report for a user."],true)
  .addBlankField(true)

.addField("!tempmute",["mutes a user."],true)
.addField("!link",["makes an invite for this server"],true)
      .addBlankField(true)

.addField("!invite",["the invite for the bot."],true)

.addField("!servers",["shows what servers the bot is in."],true)
      .addBlankField(true)

.addField("!ping",["gets the ping for the bot"],true)
    
.addField("!clear",["clears the messages"],true)
      .addBlankField(true)

.addField("!prefix",["changes the bot prefix"],true)
.addField("!addrole",["gives the user the role"],true)
      .addBlankField(true)
    .addField("!votekick",["gives user the option to kick people"],true)


.addField("More commands comming soon.",["Bot Made By Mage YT#5912"],true)

    message.channel.send(serverembed);
}

module.exports.help = {
  name:"helpmod"
}